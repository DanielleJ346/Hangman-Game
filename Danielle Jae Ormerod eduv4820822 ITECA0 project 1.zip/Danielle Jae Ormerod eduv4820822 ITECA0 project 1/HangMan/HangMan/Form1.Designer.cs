﻿namespace HangMan
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.hangmanDrawingGroup = new System.Windows.Forms.GroupBox();
            this.hangmanDrawing = new System.Windows.Forms.Panel();
            this.letterGroupBox = new System.Windows.Forms.GroupBox();
            this.scoreLabel = new System.Windows.Forms.Label();
            this.wrongWordGuesses = new System.Windows.Forms.Label();
            this.missedLetters = new System.Windows.Forms.Label();
            this.wordLength = new System.Windows.Forms.Label();
            this.buttonGroupBox = new System.Windows.Forms.GroupBox();
            this.quitBtn = new System.Windows.Forms.Button();
            this.newGameBtn = new System.Windows.Forms.Button();
            this.guessWordTxt = new System.Windows.Forms.TextBox();
            this.guessLetterTxt = new System.Windows.Forms.TextBox();
            this.guessWordBtn = new System.Windows.Forms.Button();
            this.guessLetterBtn = new System.Windows.Forms.Button();
            this.scoreboardListBox = new System.Windows.Forms.ListBox();
            this.correctLettersLabel = new System.Windows.Forms.Label();
            this.remainingGuessesLabel = new System.Windows.Forms.Label();
            this.gameStatusLabel = new System.Windows.Forms.Label();
            this.hangmanDrawingGroup.SuspendLayout();
            this.hangmanDrawing.SuspendLayout();
            this.letterGroupBox.SuspendLayout();
            this.buttonGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // hangmanDrawingGroup
            // 
            this.hangmanDrawingGroup.Controls.Add(this.hangmanDrawing);
            this.hangmanDrawingGroup.Location = new System.Drawing.Point(422, 12);
            this.hangmanDrawingGroup.Name = "hangmanDrawingGroup";
            this.hangmanDrawingGroup.Size = new System.Drawing.Size(268, 388);
            this.hangmanDrawingGroup.TabIndex = 0;
            this.hangmanDrawingGroup.TabStop = false;
            // 
            // hangmanDrawing
            // 
            this.hangmanDrawing.Controls.Add(this.gameStatusLabel);
            this.hangmanDrawing.Controls.Add(this.remainingGuessesLabel);
            this.hangmanDrawing.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hangmanDrawing.Location = new System.Drawing.Point(3, 16);
            this.hangmanDrawing.Name = "hangmanDrawing";
            this.hangmanDrawing.Size = new System.Drawing.Size(262, 369);
            this.hangmanDrawing.TabIndex = 0;
            // 
            // letterGroupBox
            // 
            this.letterGroupBox.Controls.Add(this.correctLettersLabel);
            this.letterGroupBox.Controls.Add(this.scoreboardListBox);
            this.letterGroupBox.Controls.Add(this.scoreLabel);
            this.letterGroupBox.Controls.Add(this.wrongWordGuesses);
            this.letterGroupBox.Controls.Add(this.missedLetters);
            this.letterGroupBox.Controls.Add(this.wordLength);
            this.letterGroupBox.Location = new System.Drawing.Point(12, 12);
            this.letterGroupBox.Name = "letterGroupBox";
            this.letterGroupBox.Size = new System.Drawing.Size(404, 281);
            this.letterGroupBox.TabIndex = 1;
            this.letterGroupBox.TabStop = false;
            // 
            // scoreLabel
            // 
            this.scoreLabel.AutoSize = true;
            this.scoreLabel.Location = new System.Drawing.Point(221, 213);
            this.scoreLabel.Name = "scoreLabel";
            this.scoreLabel.Size = new System.Drawing.Size(41, 13);
            this.scoreLabel.TabIndex = 3;
            this.scoreLabel.Text = "Score: ";
            // 
            // wrongWordGuesses
            // 
            this.wrongWordGuesses.AutoSize = true;
            this.wrongWordGuesses.Location = new System.Drawing.Point(6, 262);
            this.wrongWordGuesses.Name = "wrongWordGuesses";
            this.wrongWordGuesses.Size = new System.Drawing.Size(114, 13);
            this.wrongWordGuesses.TabIndex = 2;
            this.wrongWordGuesses.Text = "Wrong word guessed: ";
            // 
            // missedLetters
            // 
            this.missedLetters.AutoSize = true;
            this.missedLetters.Location = new System.Drawing.Point(6, 229);
            this.missedLetters.Name = "missedLetters";
            this.missedLetters.Size = new System.Drawing.Size(117, 13);
            this.missedLetters.TabIndex = 1;
            this.missedLetters.Text = "Wrong letter guessed:  ";
            // 
            // wordLength
            // 
            this.wordLength.AutoSize = true;
            this.wordLength.Location = new System.Drawing.Point(221, 262);
            this.wordLength.Name = "wordLength";
            this.wordLength.Size = new System.Drawing.Size(75, 13);
            this.wordLength.TabIndex = 0;
            this.wordLength.Text = "Word Length: ";
            // 
            // buttonGroupBox
            // 
            this.buttonGroupBox.Controls.Add(this.quitBtn);
            this.buttonGroupBox.Controls.Add(this.newGameBtn);
            this.buttonGroupBox.Controls.Add(this.guessWordTxt);
            this.buttonGroupBox.Controls.Add(this.guessLetterTxt);
            this.buttonGroupBox.Controls.Add(this.guessWordBtn);
            this.buttonGroupBox.Controls.Add(this.guessLetterBtn);
            this.buttonGroupBox.Location = new System.Drawing.Point(12, 299);
            this.buttonGroupBox.Name = "buttonGroupBox";
            this.buttonGroupBox.Size = new System.Drawing.Size(404, 101);
            this.buttonGroupBox.TabIndex = 2;
            this.buttonGroupBox.TabStop = false;
            // 
            // quitBtn
            // 
            this.quitBtn.Location = new System.Drawing.Point(200, 65);
            this.quitBtn.Name = "quitBtn";
            this.quitBtn.Size = new System.Drawing.Size(178, 30);
            this.quitBtn.TabIndex = 5;
            this.quitBtn.Text = "Quit";
            this.quitBtn.UseVisualStyleBackColor = true;
            this.quitBtn.Click += new System.EventHandler(this.quitBtn_Click);
            // 
            // newGameBtn
            // 
            this.newGameBtn.Location = new System.Drawing.Point(17, 65);
            this.newGameBtn.Name = "newGameBtn";
            this.newGameBtn.Size = new System.Drawing.Size(177, 30);
            this.newGameBtn.TabIndex = 4;
            this.newGameBtn.Text = "New Game";
            this.newGameBtn.UseVisualStyleBackColor = true;
            this.newGameBtn.Click += new System.EventHandler(this.newGameBtn_Click);
            // 
            // guessWordTxt
            // 
            this.guessWordTxt.Location = new System.Drawing.Point(278, 29);
            this.guessWordTxt.Name = "guessWordTxt";
            this.guessWordTxt.Size = new System.Drawing.Size(100, 20);
            this.guessWordTxt.TabIndex = 3;
            this.guessWordTxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.guessWordTxt_KeyDown);
            // 
            // guessLetterTxt
            // 
            this.guessLetterTxt.Location = new System.Drawing.Point(116, 30);
            this.guessLetterTxt.MaxLength = 1;
            this.guessLetterTxt.Name = "guessLetterTxt";
            this.guessLetterTxt.Size = new System.Drawing.Size(35, 20);
            this.guessLetterTxt.TabIndex = 2;
            this.guessLetterTxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.guessLetterTxt_KeyDown);
            // 
            // guessWordBtn
            // 
            this.guessWordBtn.Location = new System.Drawing.Point(185, 19);
            this.guessWordBtn.Name = "guessWordBtn";
            this.guessWordBtn.Size = new System.Drawing.Size(86, 39);
            this.guessWordBtn.TabIndex = 1;
            this.guessWordBtn.Text = "Guess Word";
            this.guessWordBtn.UseVisualStyleBackColor = true;
            this.guessWordBtn.Click += new System.EventHandler(this.guessWordBtn_Click);
            // 
            // guessLetterBtn
            // 
            this.guessLetterBtn.Location = new System.Drawing.Point(17, 20);
            this.guessLetterBtn.Name = "guessLetterBtn";
            this.guessLetterBtn.Size = new System.Drawing.Size(93, 38);
            this.guessLetterBtn.TabIndex = 0;
            this.guessLetterBtn.Text = "Guess Letter";
            this.guessLetterBtn.UseVisualStyleBackColor = true;
            this.guessLetterBtn.Click += new System.EventHandler(this.guessLetterBtn_Click);
            this.guessLetterBtn.Enter += new System.EventHandler(this.guessLetterBtn_Enter);
            this.guessLetterBtn.Leave += new System.EventHandler(this.guessLetterBtn_Leave);
            // 
            // scoreboardListBox
            // 
            this.scoreboardListBox.FormattingEnabled = true;
            this.scoreboardListBox.Location = new System.Drawing.Point(224, 229);
            this.scoreboardListBox.Name = "scoreboardListBox";
            this.scoreboardListBox.Size = new System.Drawing.Size(174, 30);
            this.scoreboardListBox.TabIndex = 4;
            // 
            // correctLettersLabel
            // 
            this.correctLettersLabel.AutoSize = true;
            this.correctLettersLabel.Location = new System.Drawing.Point(6, 246);
            this.correctLettersLabel.Name = "correctLettersLabel";
            this.correctLettersLabel.Size = new System.Drawing.Size(82, 13);
            this.correctLettersLabel.TabIndex = 5;
            this.correctLettersLabel.Text = "Correct Letters: ";
            // 
            // remainingGuessesLabel
            // 
            this.remainingGuessesLabel.AutoSize = true;
            this.remainingGuessesLabel.Location = new System.Drawing.Point(3, 353);
            this.remainingGuessesLabel.Name = "remainingGuessesLabel";
            this.remainingGuessesLabel.Size = new System.Drawing.Size(105, 13);
            this.remainingGuessesLabel.TabIndex = 0;
            this.remainingGuessesLabel.Text = "Remaining guesses: ";
            // 
            // gameStatusLabel
            // 
            this.gameStatusLabel.AutoSize = true;
            this.gameStatusLabel.Location = new System.Drawing.Point(6, 4);
            this.gameStatusLabel.Name = "gameStatusLabel";
            this.gameStatusLabel.Size = new System.Drawing.Size(0, 13);
            this.gameStatusLabel.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(702, 412);
            this.Controls.Add(this.buttonGroupBox);
            this.Controls.Add(this.letterGroupBox);
            this.Controls.Add(this.hangmanDrawingGroup);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Shown += new System.EventHandler(this.Form1_Shown);
            this.hangmanDrawingGroup.ResumeLayout(false);
            this.hangmanDrawing.ResumeLayout(false);
            this.hangmanDrawing.PerformLayout();
            this.letterGroupBox.ResumeLayout(false);
            this.letterGroupBox.PerformLayout();
            this.buttonGroupBox.ResumeLayout(false);
            this.buttonGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox hangmanDrawingGroup;
        private System.Windows.Forms.Panel hangmanDrawing;
        private System.Windows.Forms.GroupBox letterGroupBox;
        private System.Windows.Forms.GroupBox buttonGroupBox;
        private System.Windows.Forms.TextBox guessLetterTxt;
        private System.Windows.Forms.Button guessWordBtn;
        private System.Windows.Forms.Button guessLetterBtn;
        private System.Windows.Forms.Label wordLength;
        private System.Windows.Forms.TextBox guessWordTxt;
        private System.Windows.Forms.Label missedLetters;
        private System.Windows.Forms.Label wrongWordGuesses;
        private System.Windows.Forms.Button quitBtn;
        private System.Windows.Forms.Button newGameBtn;
        private System.Windows.Forms.Label scoreLabel;
        private System.Windows.Forms.ListBox scoreboardListBox;
        private System.Windows.Forms.Label remainingGuessesLabel;
        private System.Windows.Forms.Label correctLettersLabel;
        private System.Windows.Forms.Label gameStatusLabel;
    }
}

