﻿// Author: Danielle Jae Ormerod
// Student number: eduv4820822
// Date: 23/10/2024
// Hangman Game

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Drawing.Drawing2D;
using System.Collections;

namespace HangMan
{
    public partial class Form1 : Form
    {
        private bool isHovered = false; // Track if the mouse is hovering over a button

        public Form1()
        {
            InitializeComponent();

            // Set background for the form
            this.Paint += new PaintEventHandler(set_background);

            // Attach custom paint and mouse events for the buttons
            AttachButtonEvents(guessLetterBtn);
            AttachButtonEvents(guessWordBtn);
            AttachButtonEvents(newGameBtn);
            AttachButtonEvents(quitBtn);
        }

        // Helper function to attach events to buttons
        private void AttachButtonEvents(Button button)
        {
            button.Paint += new PaintEventHandler(GradientButton_Paint);
            button.MouseEnter += new EventHandler(guessLetterBtn_Enter);
            button.MouseLeave += new EventHandler(guessLetterBtn_Leave);
        }

        // Custom method to set the background gradient of the form
        private void set_background(Object sender, PaintEventArgs e)
        {
            try
            {
                Graphics g = e.Graphics;
                // Create a rectangle the same size as our form
                Rectangle gradient_rectangle = new Rectangle(0, 0, Width, Height);

                // Create a linear gradient brush from black to a light blue
                Brush b = new LinearGradientBrush(gradient_rectangle, Color.FromArgb(0, 0, 0), Color.FromArgb(57, 128, 227), 65f);

                // fill the rectangle with the gradient brush
                g.FillRectangle(b, gradient_rectangle);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error setting background: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }            
        }

        // Custom gradient paint for buttons
        private void GradientButton_Paint(object sender, PaintEventArgs e)
        {
            try
            {
                Button button = sender as Button;
                Graphics g = e.Graphics;

                // Set high quality for smooth edges and better rendering
                g.SmoothingMode = SmoothingMode.AntiAlias;

                // Define the rounded rectangle with a radius of 20
                using (GraphicsPath path = CreateRoundedRectanglePath(new Rectangle(0, 0, button.Width, button.Height), 10))
                {
                    // Create the gradient brush within the button's rounded area
                    using (Brush b = new LinearGradientBrush(button.ClientRectangle,
                                  Color.FromArgb(0, 0, 0), Color.FromArgb(57, 128, 227), 65f))
                    {
                        // Fill the rounded area with the gradient
                        g.FillPath(b, path);
                    }

                    // Draw an optional border around the button (white, width 2)
                    using (Pen pen = new Pen(Color.White, 2))
                    {
                        g.DrawPath(pen, path);
                    }
                }

                // Draw the button's text centered within the rounded area
                TextRenderer.DrawText(
                    e.Graphics,
                    button.Text,
                    button.Font,
                    button.ClientRectangle,
                    Color.White,  // Text color
                    TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter
                );
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error painting button: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }

        // Helper function to create a rounded rectangle path
        private GraphicsPath CreateRoundedRectanglePath(Rectangle rect, int radius)
        {
            GraphicsPath path = new GraphicsPath();
            int diameter = radius * 2;

            // Top-left arc
            path.AddArc(rect.X, rect.Y, diameter, diameter, 180, 90);
            // Top-right arc
            path.AddArc(rect.Right - diameter, rect.Y, diameter, diameter, 270, 90);
            // Bottom-right arc
            path.AddArc(rect.Right - diameter, rect.Bottom - diameter, diameter, diameter, 0, 90);
            // Bottom-left arc
            path.AddArc(rect.X, rect.Bottom - diameter, diameter, diameter, 90, 90);
            path.CloseFigure();  // Close the path

            return path;
        }

        // Game related fields
        string word = ""; // Current word to guess
        List<Label> labels = new List<Label>(); // Labels to display guessed letters
        int amount = 0; // count of incorrect guesses
        HashSet<char> guessedLetters = new HashSet<char>();  // Track guessed letters
        int score = 0; // Score starts at 0
        private SortedList<int, string> scoreboard = new SortedList<int, string>(); // Scoreboard entries
        private ArrayList correctGuesses = new ArrayList(); // Store correct guesses
        private ArrayList incorrectGuesses = new ArrayList(); // Store incorrect guesses

        // Enumarator that holds all the different body parts of the hangman
        enum BodyParts
        {
            head,      // 0
            body,      // 1
            left_arm,  // 2
            right_arm, // 3
            left_leg,  // 4
            right_leg, // 5
            left_eye,  // 6
            right_eye, // 7
            mouth,     // 8
            nose       // 9
        }

        // Method to draw the base of the hangman
        void DrawHangPost()
        {
            try
            {
                // The CreateGraphics() method provides a surface for drawing on the panel
                Graphics g = hangmanDrawing.CreateGraphics();
                // Pen is used to draw lines, curves and shapes, it defines both color and thickness of the stroke
                Pen p = new Pen(Color.Brown, 7);

                int panelWidth = hangmanDrawing.Width;
                int panelHeight = hangmanDrawing.Height;

                // Calculate positions relative to the panel size
                int postX = (int)(panelWidth * 0.7);
                int postTopY = panelHeight / 10;  // 10% down from the top
                int postBottomY = panelHeight - 10;  // Near the bottom
                int beamLength = panelWidth / 4;  // Beam is 25% of panel width

                // Draws a straight line between two points
                // Draws the vertical post of the hangman stand
                // Draw the vertical post
                g.DrawLine(p, new Point(postX, postBottomY), new Point(postX, postTopY));

                // Draw the horizontal beam
                g.DrawLine(p, new Point(postX, postTopY), new Point(postX - beamLength, postTopY));

                // Draw the rope section
                g.DrawLine(p, new Point(postX - beamLength, postTopY), new Point(postX - beamLength, postTopY + 50));
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error drawing hang post: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Draws different parts of the hangman based off the BodyParts enum
        void DrawBodyPart(BodyParts parts)
        {
            try
            {
                Graphics g = hangmanDrawing.CreateGraphics();
                Pen p = new Pen(Color.Black, 2); // Pen for drawing body parts

                int panelWidth = hangmanDrawing.Width;
                int panelHeight = hangmanDrawing.Height;

                // Calculate common positions based on panel size
                int headDiameter = panelHeight / 10;  // Head is 10% of panel height
                int centerX = (int)(panelWidth * 0.7) - (panelWidth / 4) - headDiameter / 2;
                int headY = panelHeight / 10 + 50;  // Head position just below rope

                // Use the same X-coordinate for the body parts to align them with the head
                int bodyX = centerX + headDiameter / 2;  // Center of the head
                int bodyStartY = headY + headDiameter;  // Body starts where head ends
                int bodyEndY = bodyStartY + panelHeight / 4;  // Body is 25% of panel height

                int armY = bodyStartY + 10;  // Arms start slightly below the neck
                int legStartY = bodyEndY;  // Legs start where the body ends
                int legEndY = legStartY + panelHeight / 8;  // Legs are 12.5% of panel height

                // Draws the specific body part based on the enumeration value
                switch (parts)
                {
                    case BodyParts.head:
                        g.DrawEllipse(p, centerX, headY, headDiameter, headDiameter);
                        break;
                    case BodyParts.left_eye:
                        g.FillEllipse(Brushes.Black, centerX + headDiameter / 4, headY + headDiameter / 4, 5, 5);
                        break;
                    case BodyParts.right_eye:
                        g.FillEllipse(Brushes.Black, centerX + 3 * headDiameter / 4 - 5, headY + headDiameter / 4, 5, 5);
                        break;
                    case BodyParts.mouth:
                        g.DrawArc(p, centerX + headDiameter / 4, headY + headDiameter / 2, headDiameter / 2, 10, 0, 180);
                        break;
                    case BodyParts.body:
                        g.DrawLine(p, new Point(bodyX, bodyStartY), new Point(bodyX, bodyEndY));
                        break;
                    case BodyParts.left_arm:
                        g.DrawLine(p, new Point(bodyX, armY), new Point(bodyX - panelWidth / 8, armY - 20));
                        break;
                    case BodyParts.right_arm:
                        g.DrawLine(p, new Point(bodyX, armY), new Point(bodyX + panelWidth / 8, armY - 20));
                        break;
                    case BodyParts.left_leg:
                        g.DrawLine(p, new Point(bodyX, legStartY), new Point(bodyX - panelWidth / 8, legEndY));
                        break;
                    case BodyParts.right_leg:
                        g.DrawLine(p, new Point(bodyX, legStartY), new Point(bodyX + panelWidth / 8, legEndY));
                        break;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error drawing body part: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Create labels to represent each letter in the word to guess
        void MakeLabels()
        {
            try
            {
                word = GetRandomWord().Trim();  // Retrieve and trim the random word
                char[] chars = word.ToCharArray();  // Convert the word to a char array
                int between = Math.Min(30, 330 / chars.Length);  // Calculate spacing to prevent overlap

                // Clear any existing labels from both the UI and list
                foreach (Label label in labels)
                {
                    letterGroupBox.Controls.Remove(label);  // Remove from the UI
                    label.Dispose();  // Dispose the label to free memory
                }
                labels.Clear();  // Clear the list to avoid duplicates

                // Create a label for each character in the word
                for (int i = 0; i < chars.Length; i++)
                {
                    Label label = new Label
                    {
                        AutoSize = true,
                        Location = new Point((i * between) + 10, 80), // Position the label
                        Text = "_", // Initialize label with an underscore
                        Parent = letterGroupBox
                    };
                    label.BringToFront(); // Bring the label to the front
                    labels.Add(label); // Add label to the list
                }

                // Display the correct word length
                wordLength.Text = "Word Length: " + chars.Length.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error creating labels: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Add an entry to the scoreboard
        private void AddToScoreboard(int guesses, string word)
        {
            try
            {
                // Add a new entry to the scoreboard list
                scoreboard.Add(guesses, word);
                UpdateScoreboardListBox(); // Update the display of the scoreboard
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding to scoreboard: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }

        // Update the scoreboard display in the UI
        private void UpdateScoreboardListBox()
        {
            try
            {
                scoreLabel.Text = "Score: " + score; // Display current score
                // Clear the list box before adding new items
                scoreboardListBox.Items.Clear();

                // Add each entry to the list box
                foreach (var entry in scoreboard)
                {
                    scoreboardListBox.Items.Add($"Guesses: {entry.Key} - Word: {entry.Value}");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating scoreboard: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Get a random word from a predefined list
        private string GetRandomWord()
        {
            try
            {
                string[] words = {
                "abilities", "culture", "hallmark", "principles", "strategies",
                "academic", "curriculum", "help", "priorities", "student",
                "accurate", "achievement", "dedicated", "identify", "procedures",
                "actions", "design", "improvement", "success", "advocacy",
                "alert", "develop", "independence", "promotion", "teaching",
                "appropriate", "individual", "purpose", "timely", "attainment",
                "attention", "innovative", "realistic", "trust", "available",
                "aware", "integrity", "recognize", "benefit", "interaction",
                "building", "encourage", "knowledge", "challenge", "enhance",
                "leadership", "changes", "lifelong", "respond", "choices",
                "citizens", "ethical", "responsible", "clarification", "materials",
                "commitment", "exploration", "mentor", "motivation", "community",
                "concern", "foundation", "partners", "cooperation", "positive",
                "create", "guide", "potential", "coordinate", "growth", "solve",
                "critical", "persistence", "skills", "communication", "society"
            };

                // Generate a random index to select a word from the above array
                Random random = new Random();
                int index = random.Next(words.Length);

                // return the randomly selected word trimmed of any extra whitespaces
                return words[index].Trim();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error fetching random word: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return "default"; // Default word if fetch fails
            }
        }

        private void Form1_Shown(object sender, EventArgs e)
        {
            DrawHangPost();
            MakeLabels();
        }

        // Handle button clicks for guessing letters
        private void guessLetterBtn_Click(object sender, EventArgs e)
        {
            // Ensure the user entered at least one character
            if (string.IsNullOrWhiteSpace(guessLetterTxt.Text))
            {
                MessageBox.Show("Please enter a letter!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            char letter = guessLetterTxt.Text.ToLower()[0]; // Get the first character
            guessLetterTxt.Clear(); // Clear input field after guess

            if (!char.IsLetter(letter))
            {
                MessageBox.Show("You can only submit letters!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (guessedLetters.Contains(letter))
            {
                MessageBox.Show($"The letter '{letter}' has already been entered!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Add the guessed letter to the guessedLetters set
            guessedLetters.Add(letter);

            // Check if the guessed letter is in the word
            if (word.Contains(letter))
            {
                char[] letters = word.ToCharArray(); // Convert word to char array
                correctGuesses.Add(letter); // Add to correct guesses

                // Update the labels for each occurrence of the guessed letter
                for (int i = 0; i < letters.Length; i++)
                {
                    if (letters[i] == letter)
                    {
                        labels[i].Text = letter.ToString();
                        // Update the correct letters label properly
                        correctLettersLabel.Text += letter + ", ";
                    }
                }

                // Increment score and update scoreboard
                score += 10;
                UpdateScoreboardListBox();

                // Update remaining guesses and game status
                remainingGuessesLabel.Text = $"Remaining guesses: {10 - amount}";
                gameStatusLabel.Text = "Keep going!";

                // Check if the user has won (all labels filled)
                if (labels.All(label => label.Text != "_"))
                {
                    MessageBox.Show("You have won!", "Congrats");
                    AddToScoreboard(amount, word); // Log the win
                    ResetGame(); // Start a new game
                }
            }
            else
            {
                // Handle incorrect guesses
                score -= 5; // Deduct points for wrong guess
                incorrectGuesses.Add(letter); // Track incorrect guess

                // Update missed letters and scoreboard
                missedLetters.Text += $" {letter}, ";
                DrawBodyPart((BodyParts)amount); // Draw part of the hangman
                amount++; // Increment incorrect guess count

                // Update remaining guesses and game status
                remainingGuessesLabel.Text = $"Remaining guesses: {10 - amount}";
                gameStatusLabel.Text = "Try again!";

                // Check if the user has lost (all parts drawn)
                if (amount == 10)
                {
                    MessageBox.Show($"Sorry, you lost! The word was '{word}'.");
                    AddToScoreboard(amount, word); // Log the loss
                    ResetGame(); // Start a new game
                }
            }
        }

        // Reset the game sta5te
        void ResetGame()
        {
            try
            {
                Graphics g = hangmanDrawing.CreateGraphics();
                g.Clear(hangmanDrawing.BackColor);

                MakeLabels(); // Create new labels for the new word
                DrawHangPost(); // Draw the initial hang post
                guessedLetters.Clear(); // Clear previously guessed letters
                correctGuesses.Clear(); // Clear correct guesses
                incorrectGuesses.Clear(); // Clear incorrect guesses
                missedLetters.Text = "Wrong letter guessed: "; // Clear previosuly missed letters
                guessLetterTxt.Text = ""; // Clear previous word length display
                amount = 0; // Reset incorrect gues count

                correctLettersLabel.Text = "Correct letters: ";
                remainingGuessesLabel.Text = $"Remaining guesses: {10}";
                gameStatusLabel.Text = "Make a guess!"; // Reset status label
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error starting new game: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }

        // Pressing enter to submit a letter
        private void guessLetterTxt_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)  // Check if Enter was pressed
            {
                guessLetterBtn_Click(sender, e);  // Trigger letter guess event
                e.SuppressKeyPress = true;  // Prevent the ding sound on Enter
            }
        }

        // Pressing enter to submit word
        private void guessWordTxt_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)  // Check if Enter was pressed
            {
                guessWordBtn_Click(sender, e);  // Trigger word guess event
                e.SuppressKeyPress = true;  // Prevent the ding sound on Enter
            }
        }

        // handle click event for the new game button
        private void newGameBtn_Click(object sender, EventArgs e)
        {
            ResetGame();  // Reset the game for a new round
            MessageBox.Show("A new game has started!", "New Game", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        // handle click event for the quit button
        private void quitBtn_Click(object sender, EventArgs e)
        {
            try
            {
                var result = MessageBox.Show("Are you sure you want to quit?", "Quit",
                                 MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    Application.Exit();  // Close the application
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error quitting the game: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }

        // handle hover events for buttons to chnage appearance
        private void guessLetterBtn_Enter(object sender, EventArgs e)
        {
            try
            {
                Button button = sender as Button;
                button.BackColor = Color.FromArgb(57, 128, 227);
                button.ForeColor = Color.White;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error on mouse enter: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void guessLetterBtn_Leave(object sender, EventArgs e)
        {
            try
            {
                Button button = sender as Button;
                button.BackColor = SystemColors.Control; // Reset to default
                button.ForeColor = Color.Black; // Reset to default
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error on mouse leave: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Handle button clicks for guessing words
        private void guessWordBtn_Click(object sender, EventArgs e)
        {
            // Clear the text box after the guess
            string guessedWord = guessWordTxt.Text.ToLower().Trim();
            guessWordTxt.Clear();

            // Check if the guessed word is correct
            if (guessWordTxt.Text == word)
            {
                score += 50; // increment the score for correctly guessing the word
                UpdateScoreboardListBox();

                MessageBox.Show("You have won!", "Congrats");
                ResetGame();
            }
            else
            {
                score -= 10; // decrement the score for incorrect word guess
                UpdateScoreboardListBox();

                // Add the wrong guess to the wrong word guesses label
                wrongWordGuesses.Text += guessedWord + ", ";

                MessageBox.Show("The word that you have guessed is wrong!", "Sorry");
                DrawBodyPart((BodyParts)amount);
                amount++;

                // Check if all parts are drawn (loss condition)
                if (amount == 10)
                {
                    MessageBox.Show($"Sorry, you lost! The word was '{word}'.");
                    ResetGame();
                }
            }
        }
    }
}
